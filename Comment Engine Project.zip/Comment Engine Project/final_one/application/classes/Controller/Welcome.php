<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Welcome extends Controller {
        
    public function action_index(){
        
        $comment= ORM::factory('Comments')->find_all();
        $records=ORM::factory('Comments')->where->count_all();
        $view=View::factory('site')->bind('Comments',$comment);
        //get the first comment on row zero
        $view->comment=$this->response->body("<b>".$comment[1]->username."</b><br  />says<br  />".$comment[1]->comment."on <br  />".$comment[1]->comment_date);
        
        $this->response->body($view);
//        for ($i;ORM::factory('Comments')->count_all();$i++){
//            $view->comment=$this->response->body($comment[$i]->comment);
//            
//        }
        /*working 
        $mymodel= new Model_Comments;
        
        $view=View::factory('site')->bind('Comments', $mymodel);
        $view->comment=$mymodel->get_comments();
      
        $this->response->body($view);*/
    }
    
    public function action_addComment(){
        //all main comments have parentID -1 and replies 0
        if($_POST){
            $comment= ORM::factory('Comments');
            $date= new dateTime;
            $d=$date->format('Y-m-d h:i:s');
            $comment=ORM::factory('Post');
            $comment->username=$_POST['name'];
            $comment->comment=$_POST['comment'];
            $comment->comment_date=$d;
            $comment->user_email==$_POST['email'];
            $comment->parent_Id=-1;
            $comment->save();
            $this->redirect('welcome'/index.php);
          
        }
        $view=View::factory('site');

        //echo "<script> im alive :-D</script>";
//        if(isset($_POST['m'])){
//        if(validateEmail($_POST['m']) && validateTextField(($_POST['u']))){
//            
//
//            $username=($_POST['u']);
//            $comment=($_POST['c']);
//            $email=($_POST['m']);
//            $date= new dateTime;
//            $d=$date->format('Y-m-d h:i:s');
//            
//        }
//    }
    }


} 
// End Welcome
