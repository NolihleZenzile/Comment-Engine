<?php defined('SYSPATH') OR die('No direct script access.');
/**
 * Database exceptions.
 *
 * @package    Kohana/Database
 * @category   Exceptions
 * @author     Kohana Team
 * @copyright  (c) 2009 Kohana Team
 * @license    http://kohanaphp.com/license
 */
class Kohana_Database_Exception extends Kohana_Exception {}
