$(document).ready(function(){
   $('#submit').click(function(){
        var comment=$('#comment').val();
       var email=$('#email').val();
       var username=$('#name').val();
       
       if((comment && email && username)==""){
           
         alert("please fill in all  the form fields" );
           return;
       }else{
           $.post('Welcome/addComment',{comment:comment,email:email,name:username},function(data){
               document.writeln(data);
           });
       }
   });

   });

      
           
        