<?php defined('SYSPATH') OR die('No direct script access.');

class HTTP_Header extends Kohana_HTTP_Header {}
