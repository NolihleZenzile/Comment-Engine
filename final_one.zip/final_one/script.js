var pid;
$(document).ready(function(){
    
   $('#submit').click(function(){
        var comment=$('#comment').val();
       var email=$('#email').val();
       var username=$('#name').val();
       
       if((comment && email && username)==""){
           
         alert("please fill in all  the form fields" );
           return;
       }else{
           $.post("Welcome/addComment",{comment:comment,email:email,name:username},function(data){
               alert(data);
           });
       }
   });
   /* all about the replies*/
   $('#reply').click(function(Commentid){
        id=Commentid;
	$('#reply_form_background').fadeIn();
	$('#reply_form').fadeIn();
        $('#close').fadeIn();
        return false;
   });
   
   $('#reply_form_background').click(function(){
       
	$('#reply_form_background').fadeOut();
	$('#reply_form').fadeOut();
        $('#close').fadeOut();
        return false;
   });
   
   
   
    $('#close').click(function(){
       
	$('#reply_form_background').fadeOut();
	$('#reply_form').fadeOut();
        $('#close').fadeOut();
        return false;
   });
   
   $('#btnReply').click(function(){
       
       var reply=$('#txtreply').val();
       var r_email=$('#replyer_email').val();
       var replyer=$('#replyer').val();
       
       if((reply&& r_email&& replyer)===""){
           alert('fill in the form fields');
           
       }else{
           var comment_id= getID();
           try{
         $.post("Welcome/reply",{reply:reply,replyer_email:r_email,replyer:replyer,parent_id:comment_id},function(data){
            if(data){
                alert('reply posted');
            }else{
                alert('error posting your reply');
            }
            return false;
         });
     }catch(err){
         alert("reply could not be posted" + err.message);
     }
       }
   });
   
    
   });
   function setID(id){
       this.pid=parseInt(id);
       
   }
   function getID(){
       return this.pid;
   }
   
   
   

      
           
        