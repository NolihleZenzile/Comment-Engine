<html>
    <head>
        <title>final kohana</title>
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <script type="text/javascript" src="jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="script.js"></script>
    </head>
    <body>

        <div id="reply_form_background"></div>
        <div id="reply_form">
            <span id="close">&times;</span> 
            <!----reply form---->
            <form >
                <div>
                    <input type="text" id="replyer" palceholder="user_name" /><br   />
                    <input type="email"  id="replyer_email" palceholder="email" /><br   />
                    <textarea id="txtreply" cols="20" rows="5" palceholder="reply"></textarea>
                    <input type="submit" id="btnReply" value="reply" />
                </div>
            </form>
        </div>
        <div id="main">
            <div id="addCommentContainer">
                <p>Add a Comment</p>


                <div>
                    <!------comment form------->
                    <form id="addCommentForm" method="post" action="">
                        <div>
                            <label for="name">Your Name</label>
                            <input type="text" id="name" />

                            <label for="email">Your Email</label><br />
                            <input type="email" name="email" id="email" /><br />

                            <label for="body">Comment Body</label>
                            <textarea id="comment" cols="20" rows="5"></textarea>
                            <input type="submit" id="submit" value="Submit" />
                        </div>
                    </form>
                </div>



            </div>

        </div>
        <div id="comments">
            <?php

            function workReplies($commentID, $replies) {
                $repliesDiv = "<div id='replies'>";
                foreach ($replies as $reply) {

                    $run = ($reply->parent_Id == $commentID) ? (true) : (false);
                    if ($run) {
                        $repliesDiv.="<i><b>$reply->username</b> replied:</i> <br>" . $reply->comment . "<br/> on: $reply->comment_date <br  /><hr />";
                    }
                }
                if (isset($repliesDiv) && !empty($repliesDiv) && $repliesDiv != "<div id='replies'>") {
                    return $repliesDiv.="</div>";
                } else {
                    return $repliesDiv = '';
                }
            }

            
            $html = "";

            foreach ($Comments as $comment) {
                $comment_replies = workReplies($comment->comment_ID, $replies);

                $html.="<div class='comment' ><i> $comment->username says.... </i> <p class=''>$comment->comment </p><br  /><br  />  on  $comment->comment_date
                        <a id='reply'+ $comment->comment_ID' href='#' onclick=setID($comment->comment_ID)>reply</a></div> $comment_replies<br  />";
            }

            echo $html;
            ?>


        </div>



    </body>

</html>