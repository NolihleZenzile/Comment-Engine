<html>
    <head>
        <title>sign in</title>
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <script type="text/javascript" src="jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="script.js"></script>
    </head>
    <body>
        
        
                    
                    
        <div id="main">
            <div id="addCommentContainer">
                <form action="cms/login" method="post" autocomplete="off">
                    <input type="text" placeholder="user name"/><br  />
                    <input type="password" placeholder="password"/><br  />
                    <input type="submit" value="sign_in"/>
                        
                </form>
            </div>

        </div>
        



    </body>

</html>