
<table border="1px" width="100%">
    <th>Name</th>
    <th>Email</th>
    <th>Comment</th>
    <th>Edit</th>
    <th>Delete</th>
    <?php
        foreach($comments as $comment)
        {
              $id = $comment->comment_ID;
              $table ='
                      <tr>
                            <td>'.$comment->username.'</td>
                            <td>'.$comment->user_email.'</td>
                            <td>'.$comment->comment.'</td>
                      
                            <td>'.HTML::anchor("#","Edit").'</td>
                            <td>'.HTML::anchor("#","Delete").'</td>
                      </tr>';
                   echo $table;      
        }
    ?>
</table>


