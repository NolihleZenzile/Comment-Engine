<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2016-10-24 02:47:55 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'comments.id' in 'field list' [ SELECT COUNT(`comments`.`id`) AS `records_found` FROM `comments` AS `comments` ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 02:47:55 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(1, 'SELECT COUNT(`c...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1648): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(8): Kohana_ORM->count_all()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 02:56:28 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ MODPATH\orm\classes\Kohana\ORM.php [ 44 ] in C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php:44
2016-10-24 02:56:28 --- DEBUG: #0 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(44): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\wamp64\\www\\f...', 44, Array)
#1 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(9): Kohana_ORM::factory(Object(Database_MySQLi_Result))
#2 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php:44
2016-10-24 02:57:56 --- CRITICAL: ErrorException [ 8 ]: Undefined property: Controller_Welcome::$_table_id ~ APPPATH\classes\Controller\Welcome.php [ 10 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 02:57:56 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(10): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\wamp64\\www\\f...', 10, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 02:58:26 --- CRITICAL: ErrorException [ 2 ]: Missing argument 3 for Kohana_ORM::where(), called in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php on line 10 and defined ~ MODPATH\orm\classes\Kohana\ORM.php [ 1849 ] in C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php:1849
2016-10-24 02:58:26 --- DEBUG: #0 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1849): Kohana_Core::error_handler(2, 'Missing argumen...', 'C:\\wamp64\\www\\f...', 1849, Array)
#1 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(10): Kohana_ORM->where('comment_ID', 2)
#2 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#7 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#8 {main} in C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php:1849
2016-10-24 02:59:09 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'comments.id' in 'field list' [ SELECT COUNT(`comments`.`id`) AS `records_found` FROM `comments` AS `comments` WHERE `comment_ID` = 2 ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 02:59:09 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(1, 'SELECT COUNT(`c...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1648): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(11): Kohana_ORM->count_all()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 03:00:57 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'comments.id' in 'field list' [ SELECT COUNT(`comments`.`id`) AS `records_found` FROM `comments` AS `comments` WHERE `comment_ID` = 'comment_ID' ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 03:00:57 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(1, 'SELECT COUNT(`c...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1648): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(11): Kohana_ORM->count_all()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 03:07:47 --- CRITICAL: ErrorException [ 4096 ]: Object of class Database_MySQLi_Result could not be converted to string ~ APPPATH\classes\Controller\Welcome.php [ 8 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:8
2016-10-24 03:07:47 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(8): Kohana_Core::error_handler(4096, 'Object of class...', 'C:\\wamp64\\www\\f...', 8, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:8
2016-10-24 03:08:57 --- CRITICAL: Database_Exception [ 1054 ]: Unknown column 'comments.id' in 'field list' [ SELECT COUNT(`comments`.`id`) AS `records_found` FROM `comments` AS `comments` ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 03:08:57 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(1, 'SELECT COUNT(`c...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1648): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(8): Kohana_ORM->count_all()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#8 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#9 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 03:15:23 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comments ~ APPPATH\classes\Controller\Welcome.php [ 14 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:14
2016-10-24 03:15:23 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(14): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 14, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:14
2016-10-24 03:16:05 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Database_MySQLi_Result::where() ~ APPPATH\classes\Controller\Welcome.php [ 14 ] in file:line
2016-10-24 03:16:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 04:35:07 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant Length - assumed 'Length' ~ APPPATH\classes\Controller\Welcome.php [ 10 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 04:35:07 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(10): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\wamp64\\www\\f...', 10, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 04:35:42 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant length - assumed 'length' ~ APPPATH\classes\Controller\Welcome.php [ 10 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 04:35:42 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(10): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\wamp64\\www\\f...', 10, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:10
2016-10-24 05:29:02 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 21 ] in file:line
2016-10-24 05:29:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:30:21 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 21 ] in file:line
2016-10-24 05:30:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:30:45 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 21 ] in file:line
2016-10-24 05:30:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:31:10 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 21 ] in file:line
2016-10-24 05:31:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:41:56 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 05:41:56 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(23): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 05:43:31 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:43:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:44:05 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:44:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:44:33 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:44:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:44:47 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:44:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:45:00 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:45:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:45:50 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:45:50 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:47:14 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:47:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:48:03 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function action_workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:48:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:49:59 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:49:59 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 05:53:06 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 05:53:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:04:07 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 06:04:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:06:35 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function workComments() ~ APPPATH\classes\Controller\Welcome.php [ 22 ] in file:line
2016-10-24 06:06:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:06:46 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:06:46 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(23): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:07:18 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:07:18 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(23): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:11:20 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: bool ~ APPPATH\classes\Controller\Welcome.php [ 23 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:23
2016-10-24 06:11:20 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(23): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 23, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:23
2016-10-24 06:14:21 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 702 ] in file:line
2016-10-24 06:14:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:15:36 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1100 ] in file:line
2016-10-24 06:15:36 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:16:06 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:16:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:16:06 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:16:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:17:20 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:17:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:17:28 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:17:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:20:09 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 463 ] in file:line
2016-10-24 06:20:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:27:07 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ APPPATH\classes\Controller\Welcome.php [ 28 ] in file:line
2016-10-24 06:27:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:27:09 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 700 ] in file:line
2016-10-24 06:27:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:34:00 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 700 ] in file:line
2016-10-24 06:34:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:40:08 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 463 ] in file:line
2016-10-24 06:40:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:42:15 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:42:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:42:57 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 1122 ] in file:line
2016-10-24 06:42:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:43:04 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:04 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(38): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:06 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:06 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(38): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:07 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:07 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(38): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:08 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:43:08 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(38): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 06:44:44 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 463 ] in file:line
2016-10-24 06:44:44 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 06:45:55 --- CRITICAL: ErrorException [ 1 ]: Maximum execution time of 120 seconds exceeded ~ MODPATH\orm\classes\Kohana\ORM.php [ 252 ] in file:line
2016-10-24 06:45:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 07:00:39 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:00:39 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(39): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:01:46 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:01:46 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(39): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:04:40 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:04:40 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(39): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:04:42 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comment ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:04:42 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(39): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:06:37 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comments ~ APPPATH\views\site.php [ 40 ] in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:06:37 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(40): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 40, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(39): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:40
2016-10-24 07:10:54 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comments ~ APPPATH\views\site.php [ 42 ] in C:\wamp64\www\final_one\application\views\site.php:42
2016-10-24 07:10:54 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(42): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 42, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:42
2016-10-24 07:15:09 --- CRITICAL: ErrorException [ 1 ]: Cannot use object of type Model_Comments as array ~ APPPATH\views\site.php [ 43 ] in file:line
2016-10-24 07:15:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 07:19:04 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: html ~ APPPATH\views\site.php [ 44 ] in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:04 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(44): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 44, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:41 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: html ~ APPPATH\views\site.php [ 44 ] in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:41 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(44): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 44, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:43 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: html ~ APPPATH\views\site.php [ 44 ] in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:43 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(44): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 44, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:45 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: html ~ APPPATH\views\site.php [ 44 ] in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:19:45 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(44): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 44, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:44
2016-10-24 07:35:21 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: comments ~ APPPATH\views\site.php [ 32 ] in C:\wamp64\www\final_one\application\views\site.php:32
2016-10-24 07:35:21 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(32): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 32, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(14): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:32
2016-10-24 09:09:32 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\views\site.php [ 14 ] in file:line
2016-10-24 09:09:32 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 09:25:28 --- CRITICAL: ErrorException [ 4096 ]: Argument 3 passed to Kohana_Form::submit() must be of the type array, string given, called in C:\wamp64\www\final_one\application\views\site.php on line 23 and defined ~ SYSPATH\classes\Kohana\Form.php [ 354 ] in C:\wamp64\www\final_one\system\classes\Kohana\Form.php:354
2016-10-24 09:25:28 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\Form.php(354): Kohana_Core::error_handler(4096, 'Argument 3 pass...', 'C:\\wamp64\\www\\f...', 354, Array)
#1 C:\wamp64\www\final_one\application\views\site.php(23): Kohana_Form::submit('post', 'post', 'onclick=validat...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#4 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#6 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#8 [internal function]: Kohana_Controller->execute()
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#12 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#13 {main} in C:\wamp64\www\final_one\system\classes\Kohana\Form.php:354
2016-10-24 09:59:57 --- CRITICAL: Database_Exception [ 1364 ]: Field 'user_email' doesn't have a default value [ INSERT INTO `comments` (`username`, `comment`, `comment_date`, `parent_Id`) VALUES ('lusapho', 'im a stupid virgin', '2016-10-24 09:59:57', -1) ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 09:59:57 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(29): Kohana_ORM->save()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 10:00:58 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:00:58 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:20:17 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:20:17 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:09 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:09 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:13 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:13 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:17 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:17 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:47 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:49:47 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:54:23 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ SYSPATH\classes\Kohana\URL.php [ 255 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:255
2016-10-24 10:54:23 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(255): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\wamp64\\www\\f...', 255, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(105): Kohana_URL::is_trusted_host('localhost:8080')
#2 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#3 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#4 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#6 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#7 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#8 [internal function]: Kohana_Controller->execute()
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#12 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#13 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:255
2016-10-24 10:55:07 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function push() ~ SYSPATH\classes\Kohana\URL.php [ 255 ] in file:line
2016-10-24 10:55:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 10:55:24 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function push() ~ SYSPATH\classes\Kohana\URL.php [ 255 ] in file:line
2016-10-24 10:55:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 10:56:37 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ SYSPATH\classes\Kohana\URL.php [ 255 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:255
2016-10-24 10:56:37 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(255): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\wamp64\\www\\f...', 255, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(105): Kohana_URL::is_trusted_host('localhost:8080')
#2 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#3 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#4 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#6 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#7 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#8 [internal function]: Kohana_Controller->execute()
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#12 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#13 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:255
2016-10-24 10:57:10 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected end of file, expecting function (T_FUNCTION) ~ SYSPATH\classes\Kohana\URL.php [ 276 ] in file:line
2016-10-24 10:57:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2016-10-24 10:57:30 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 10:57:30 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 11:03:20 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 11:03:20 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 15:05:09 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 15:05:09 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 17:40:53 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:40:53 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:43:13 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:43:13 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:44:05 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:44:05 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:45:47 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: _SESSION ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:45:47 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:46:54 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant session_start - assumed 'session_start' ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:46:54 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:47:11 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:47:11 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:52:00 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: _SESSION ~ APPPATH\views\site.php [ 13 ] in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:52:00 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(13): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 13, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:13
2016-10-24 17:55:13 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 17:55:13 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(50): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 18:11:54 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ SYSPATH\classes\Kohana\HTML.php [ 71 ] in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 18:11:54 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(71): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\wamp64\\www\\f...', 71, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(338): Kohana_HTML::chars(Array)
#2 C:\wamp64\www\final_one\system\classes\Kohana\Form.php(107): Kohana_HTML::attributes(Array)
#3 C:\wamp64\www\final_one\application\views\site.php(18): Kohana_Form::input('email', Array)
#4 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#5 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#6 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#8 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#15 {main} in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 18:12:34 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ SYSPATH\classes\Kohana\HTML.php [ 71 ] in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 18:12:34 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(71): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\wamp64\\www\\f...', 71, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(338): Kohana_HTML::chars(Array)
#2 C:\wamp64\www\final_one\system\classes\Kohana\Form.php(107): Kohana_HTML::attributes(Array)
#3 C:\wamp64\www\final_one\application\views\site.php(18): Kohana_Form::input('email', Array)
#4 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#5 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#6 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#8 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#15 {main} in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 18:13:21 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ SYSPATH\classes\Kohana\HTML.php [ 71 ] in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 18:13:21 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(71): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\wamp64\\www\\f...', 71, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTML.php(338): Kohana_HTML::chars(Array)
#2 C:\wamp64\www\final_one\system\classes\Kohana\Form.php(107): Kohana_HTML::attributes(Array)
#3 C:\wamp64\www\final_one\application\views\site.php(18): Kohana_Form::input('email', Array)
#4 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#5 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#6 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#8 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#12 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#14 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#15 {main} in C:\wamp64\www\final_one\system\classes\Kohana\HTML.php:71
2016-10-24 19:04:27 --- CRITICAL: Database_Exception [ 1364 ]: Field 'parent_Id' doesn't have a default value [ INSERT INTO `comments` (`username`, `comment`, `comment_date`, `user_email`) VALUES ('reply', 'lopokjhvgdsvygdvjhbn cxh', '2016-10-24 07:04:27', 'pop@reply.com') ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 19:04:27 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(31): Kohana_ORM->save()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addReply()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 21:40:27 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id ~ APPPATH\views\site.php [ 16 ] in C:\wamp64\www\final_one\application\views\site.php:16
2016-10-24 21:40:27 --- DEBUG: #0 C:\wamp64\www\final_one\application\views\site.php(16): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 16, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\View.php(62): include('C:\\wamp64\\www\\f...')
#2 C:\wamp64\www\final_one\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\wamp64\\www\\f...', Array)
#3 C:\wamp64\www\final_one\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Response.php(160): Kohana_View->__toString()
#5 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(12): Kohana_Response->body(Object(View))
#6 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_index()
#7 [internal function]: Kohana_Controller->execute()
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#10 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#11 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#12 {main} in C:\wamp64\www\final_one\application\views\site.php:16
2016-10-24 21:47:29 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:47:29 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:16 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:16 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:21 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:21 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:23 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:49:23 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:50:43 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:50:43 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:50:47 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:50:47 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:51:30 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:51:30 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 21:52:29 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: type ~ APPPATH\classes\Controller\Welcome.php [ 31 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:31
2016-10-24 21:52:29 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\wamp64\\www\\f...', 31, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:31
2016-10-24 23:18:42 --- CRITICAL: ErrorException [ 8 ]: Undefined index: type ~ APPPATH\classes\Controller\Welcome.php [ 30 ] in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 23:18:42 --- DEBUG: #0 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(30): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\wamp64\\www\\f...', 30, Array)
#1 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#4 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#6 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#7 {main} in C:\wamp64\www\final_one\application\classes\Controller\Welcome.php:30
2016-10-24 23:23:17 --- CRITICAL: Database_Exception [ 1364 ]: Field 'parent_Id' doesn't have a default value [ INSERT INTO `comments` (`username`, `comment`, `comment_date`, `user_email`) VALUES ('comments', 'holpkj', '2016-10-24 11:23:17', 'polo') ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 23:23:17 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(36): Kohana_ORM->save()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 23:23:42 --- CRITICAL: Database_Exception [ 1364 ]: Field 'parent_Id' doesn't have a default value [ INSERT INTO `comments` (`username`, `comment`, `comment_date`, `user_email`) VALUES ('comments', 'holpkj', '2016-10-24 11:23:42', 'polo') ] ~ MODPATH\database\classes\Kohana\Database\MySQLi.php [ 171 ] in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 23:23:42 --- DEBUG: #0 C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_MySQLi->query(2, 'INSERT INTO `co...', false, Array)
#1 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1324): Kohana_Database_Query->execute(Object(Database_MySQLi))
#2 C:\wamp64\www\final_one\modules\orm\classes\Kohana\ORM.php(1421): Kohana_ORM->create(NULL)
#3 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(37): Kohana_ORM->save()
#4 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#9 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#10 {main} in C:\wamp64\www\final_one\modules\database\classes\Kohana\Database\Query.php:251
2016-10-24 23:25:00 --- CRITICAL: Kohana_Exception [ 0 ]: Untrusted host localhost:8080. If you trust localhost:8080, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144
2016-10-24 23:25:00 --- DEBUG: #0 C:\wamp64\www\final_one\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, true)
#1 C:\wamp64\www\final_one\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('welcome', true, true)
#2 C:\wamp64\www\final_one\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('welcome')
#3 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('welcome', 302)
#4 C:\wamp64\www\final_one\application\classes\Controller\Welcome.php(38): Kohana_Controller::redirect('welcome')
#5 C:\wamp64\www\final_one\system\classes\Kohana\Controller.php(84): Controller_Welcome->action_addComment()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Welcome))
#8 C:\wamp64\www\final_one\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\wamp64\www\final_one\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 C:\wamp64\www\final_one\index.php(118): Kohana_Request->execute()
#11 {main} in C:\wamp64\www\final_one\system\classes\Kohana\URL.php:144