<?php /*defined(SYSPATH) OR die('No Direct jjjj Script Access');*/
Class Controller_Cms extends Controller{
    public function action_index() {
        $comments =ORM::factory('Cms')->find_all();
        $view = View::factory('log_in')
                ->bind('comments',$comments);
        $this->response->body($view);
          
    }
    
    function action_login(){}
    
    function action_comments(){
         $comments =ORM::factory('Cms')->find_all();
        $view = View::factory('cms_view')
                ->bind('comments',$comments);
        $this->response->body($view);
    }
    
    
    function getAll_replies(){
        
    }
    function getAll_replies_by_date(){
        
    }
    function getAll_sort_by_username(){
        
    }
    function getAll_sort_by_email(){
        
    }
    
    
}



