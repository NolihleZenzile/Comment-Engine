<?php

defined('SYSPATH') or die('No direct script access.');

class Controller_Welcome extends Controller {
    protected $cID=0;
    public function action_index() {

       //getting comments
        $comment = ORM::factory('Comments')
                ->order_by('comment_date','DESC')
                ->where('parent_Id','=', -1)
                ->find_all();
        //getting replies
        $replies =ORM::factory('Comments')
                ->where('parent_Id','!=', -1)
                ->order_by('comment_date','DESC')
                ->find_all();
        
        $view = View::factory('site')
                ->bind('Comments', $comment)
                ->bind('replies', $replies);
       $this->response->body($view);
        
        
//        $view = View::factory('site')
//                ->bind('replies', $replies);
//         //$this->response->body($view);
           
    }
    

    
    
     public function action_addComment() {
         $date = new dateTime;
        //all main comments have parentID -1 and replies 0
        if ($_POST) {
            $comment = ORM::factory('Comments');
            
            $d = $date->format('Y-m-d h:i:s');
            $comment->username = $_POST['name'];
            $comment->comment = $_POST['comment'];
            $comment->comment_date = $d;
            $comment->user_email = $_POST['email'];
            $comment->parent_Id = -1;
            $comment->save();
                
                $this->redirect('welcome/index');
                $view = View::factory('site');
            }
            
        }
    
    public function action_reply() {
         $date = new dateTime;
         $d = $date->format('Y-m-d h:i:s');
        
        if ($_POST) {
            $comment = ORM::factory('Comments');
            
            $comment->username = $_POST['replyer'];
            $comment->comment = $_POST['reply'];
            $comment->user_email = $_POST['replyer_email'];
            $comment->parent_Id = $_POST['parent_id'];
            $comment->comment_date = $d;
            $comment->save();
            $this->redirect('welcome/index');
            $view = View::factory('site');
            return true;
            
        }else{
            return false;
        }
    }
       
    

    function action_tests() {
        echo "inside test :D";
    }
    
    

}


