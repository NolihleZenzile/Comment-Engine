<?php

class Model_Cms extends ORM{
     protected $_table_name='comments';
    protected $_table_id='comment_ID';

    

}

