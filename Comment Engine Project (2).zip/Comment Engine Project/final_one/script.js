$(document).ready(function(){
   $('#submit').click(function(){
        var comment=$('#comment').val();
       var email=$('#email').val();
       var username=$('#name').val();
       
       if((comment && email && username)==""){
           
         alert("please fill in all  the form fields" );
           return;
       }else{
           $.post("?php echo Form::open('Welcome/addComment')",{comment:comment,email:email,name:username},function(data){
               document.writeln(data);
           });
       }
   });
   $('#reply').click(function(){
        
	$('#reply_form_background').fadeIn();
	$('#reply_form').fadeIn();
        $('#close').fadeIn();
        return false;
   });
   
   $('#reply_form_background').click(function(){
       
	$('#reply_form_background').fadeOut();
	$('#reply_form').fadeOut();
        $('#close').fadeOut();
        return false;
   });
   
    $('#close').click(function(){
       
	$('#reply_form_background').fadeOut();
	$('#reply_form').fadeOut();
        $('#close').fadeOut();
        return false;
   });

   });

      
           
        