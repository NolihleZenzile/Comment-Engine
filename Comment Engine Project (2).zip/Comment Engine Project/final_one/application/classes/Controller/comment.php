<?php defined(SYSPATH) OR die('No Direct Script Access');
Class Controller_Comment extends Controller{
    public function action_index(){
        echo 'comments controller';
    }
    public function action_addComment(){
        
    }
}



